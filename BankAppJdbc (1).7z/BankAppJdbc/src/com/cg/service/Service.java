package com.cg.service;

import java.sql.ResultSet;
import java.util.List;

import com.cg.bean.BankBean;
import com.cg.dao.Dao;

public class Service {

	Dao d=new Dao();
	public void service(BankBean b) {
	 
		d.createAccount(b);
  }

 public long showbalance(long bacc,String password1) {
		return d.showBal(bacc);
	}

	public  long deposit(long accountNo, String password2, long Amount) {
		return d.depositAmount(accountNo, Amount);
	}	

  public long withdraw(long account3, String password3, long Amount1) 
	{
	   return d.withdraw(account3, Amount1);
	}
	public void fund(long sour,  long dest,String password4,long amount2) 
	{
	     d.cashTransfer(sour, dest, amount2);
	}

 
/*	public ResultSet getTransactions(long accountNumber) { 
		return d.getAllTransactions(accountNumber);
	}*/
}
